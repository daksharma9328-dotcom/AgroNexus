# AgroNexus Step 8B — Status Sync Fix

This patch is based on the user's working Step 8 source.

## What it fixes
- Prevents cloud-applied state from immediately being written back over the cloud.
- Treats the latest Supabase snapshot as authoritative when it is newer than the local cloud timestamp.
- When a shared booking arrives, derives the Farmer queue status from the matching booking/token.
- Preserves local/offline behavior and existing UI/voice features.

## Install
Replace the project's `src` folder with this `src` folder. Keep your existing `.env.local` and package configuration.

## Test
1. Start Vite.
2. Open Farmer in one browser and Operator in another.
3. Ensure both show the same token.
4. Operator: Call Next Token.
5. Farmer should update automatically within about 3 seconds; no refresh should be required.
6. Then test In Progress and Completed.
