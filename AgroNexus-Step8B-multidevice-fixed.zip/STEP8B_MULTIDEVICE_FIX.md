# Step 8B Multi-device sync fix

This version fixes cloud-state feedback loops and local-state overwrites. Cloud snapshots are applied without immediately being written back. Farmer/operator use the shared booking list, and new demo tokens are generated from the current shared booking list.

Keep your existing `.env.local` out of the ZIP and configure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY locally.
